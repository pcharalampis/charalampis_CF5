function redirectToLogin() {
    window.location.href = '/loginForm';
}