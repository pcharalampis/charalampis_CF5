package gr.aueb.cf.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCf5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
